import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Layout from './components/Layout';
import Home from './pages/Home';
import Advokater from './pages/Advokater';
import Virksomhetsomrader from './pages/Virksomhetsomrader';
import Priser from './pages/Priser';
import Artikler from './pages/Artikler';
import Linker from './pages/Linker';
import Kontakt from './pages/Kontakt';
import Personvern from './pages/Personvern';

function App() {
  return (
    <Router>
      <Layout>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/advokater" element={<Advokater />} />
          <Route path="/virksomhetsomrader" element={<Virksomhetsomrader />} />
          <Route path="/priser" element={<Priser />} />
          <Route path="/artikler" element={<Artikler />} />
          <Route path="/linker" element={<Linker />} />
          <Route path="/kontakt" element={<Kontakt />} />
          <Route path="/personvern" element={<Personvern />} />
        </Routes>
      </Layout>
    </Router>
  );
}

export default App;