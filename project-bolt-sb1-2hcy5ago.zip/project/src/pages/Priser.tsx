import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';

const Priser: React.FC = () => {
  return (
    <div>
      {/* Page Hero */}
      <section className="bg-gray-900 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">
              Priser
            </h1>
          </div>
        </div>
      </section>

      {/* Pricing Content */}
      <section className="py-16 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="prose prose-lg max-w-none text-gray-700 space-y-6">
            <p>
              Advokat Håkon Malm tilbyr fri rettshjelp dersom du har krav på det. Staten dekker rettshjelp i barnefordelingssaker, felleseieskifte, økonomisk oppgjør samboerforhold, samværsrett, erstatning ved personskade, utkastelse fra bolig, oppsigelse/avskjed arbeidsforhold, klagesaker etter folketrygdloven hvis du oppfyller inntekts- og formuesvilkårene i rettshjelpsloven. I barnevernsaker, voldssaker, straffesaker av et visst omfang og visse andre saker dekker staten utgiftene uavhengig av størrelsen på din inntekt. Ta kontakt så kan du få mer detaljert info vedrørende fri rettshjelp og de vilkår som gjelder. I fri rettshjelpssaker er salæret på kr. 1.180,- med tilllegg av merverdiavgift. I visse tilfeller må det innbetales en egenandel. Inntektsgrensen for fri rettshjelp er pr. 2023 på kr. 350.000,- for enslige og kr. 540.000,- for ektefeller/samboere
            </p>

            <p>
              Dersom du har en innboforsikring eller husforsikring, så innholder denne en rettshjelpsforsikring. I en del saker dekkes utgiftene til advokat gjennom forsikringene, bl.a. ved mangler ved boligsalg, grensetvister, husleietvister m.m. Egenandelen består her av en grunnandel på kr. 4.000,- og en tilleggsandel på 20 % av det overskytende. Dette gjelder fra tvistetidspunktet og i de tilfeller hvor man har krav på rettshjelpdekning inngis det søknad i regi av undertegnede.
            </p>

            <p>
              Salæret/honoraret beregnes i henhold til advokatforeningens retningslinjer for salærberegning. Salæret fastsettes i utgangspunktet etter medgått tid, men også etter en totalvurdering av arbeidets omfang, de økonomiske interesser som er involvert og sakens vanskelighetsgrad.
            </p>

            <p>
              Veiledende timesats for advokatbistand er kr. 1.500,- med tillegg av 25 % merverdiavgift. Dersom annet ikke er avtalt faktureres oppdraget etter medgått tid.
            </p>

            <p>
              Etter at det er foretatt en gjennomgang av saken, kan det avgis en uttalelse om hva det resterende salær vil kunne beløpe seg til, eventuelt kan det avtales et fast salær for det resterende oppdrag.
            </p>

            <p>
              Det tilbys Inntil en halv times fri førstegangskonsultasjon. Dette gjelder med unntak av salær for utarbeidelse av samboeravtale, fremtidsfullmakt, testament, ektepakt, økonomisk oppgjør ved salg av bolig/fast eiendom . I slike saker utgjør medgått tid vanligvis:
            </p>

            <ul className="list-disc list-inside space-y-2">
              <li>Testament, 2-4 timer</li>
              <li>Samboeravtale, 2-4 timer</li>
              <li>Fremtidsfullmakt, 2-4 timer</li>
              <li>Ektepakt, 2,5 - 4 timer</li>
              <li>Boligsalg (utforming av kjøpekontrakt, inneståelse for riktig oppgjør, utforming og tinglysing av skjøte, gjennomføring av det økonomiske oppgjøret mellom selger og kjøper) fast pris kr. 15.000,-</li>
            </ul>

            <p>
              I tillegg kommer merverdiavgift. Ved oppdrag som medfører arbeidsomfang utover det som vanligvis gjelder for nevnte oppdrag, vil salæret beregnes i henhold til medgått tid. Dette vil i så fall fremgå av utstedt oppdragsbekreftelse. Utlegg, slikt som rettsgebyrer til staten, reiseutgifter og lignende, kommer i tillegg.
            </p>

            <p>
              I de fleste straffesaker dekker det offentlige salæret. Dette gjelder når det er tatt ut tiltale i saken. Videre dekker alltid det offentlige salæret i forbindelse med varetektsfengsling. For bistand under etterforskning kan det søkes om fri saksførsel. I saker som ender opp med utstedelse av forelegg, må klienten vanligvis selv dekke salæret etter medgått tid og i henhold til den offentlige salærsats. Dersom en etterforskning ender opp med henleggelse, vil det i noen situasjoner kunne fremsettes krav om erstatning for saksomkostningene.
            </p>

            <p>
              DenNorske Advokatforening har pålagt sine medlemmer å sende ut oppdragsbekreftelse med identifikasjon av oppdraget herunder med angivelse av hvorledes salæret vil bli beregnet og fakturert m.v. Slik oppdragsbekreftelse utstedes vanligvis etter første konsultasjon.
            </p>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
            Spørsmål om prisene?
          </h2>
          <p className="text-xl text-gray-600 mb-8">
            Kontakt oss for mer informasjon om priser og vilkår for ditt oppdrag.
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Link
              to="/kontakt"
              className="inline-flex items-center px-8 py-4 bg-teal-600 text-white font-semibold rounded-lg hover:bg-teal-700 transition-colors"
            >
              Kontakt oss
              <ArrowRight className="ml-2 h-5 w-5" />
            </Link>
            <Link
              to="/advokater"
              className="inline-flex items-center px-8 py-4 border-2 border-teal-600 text-teal-600 font-semibold rounded-lg hover:bg-teal-600 hover:text-white transition-colors"
            >
              Møt våre advokater
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Priser;
