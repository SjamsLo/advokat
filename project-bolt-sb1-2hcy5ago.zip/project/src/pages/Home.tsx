import React, { useState } from 'react';
import { ArrowRight, Scale, Users, Award, Shield, ChevronLeft, ChevronRight, Phone, Mail } from 'lucide-react';

const Home = () => {
  const [currentSlide, setCurrentSlide] = useState(0);
  
  const carouselImages = [
    'https://images.pexels.com/photos/5669602/pexels-photo-5669602.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    'https://images.pexels.com/photos/7887817/pexels-photo-7887817.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    'https://images.pexels.com/photos/5668858/pexels-photo-5668858.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  ];

  const services = [
    { id: 'selskapsjus', icon: Scale, title: 'Selskapsjus', description: 'Rådgivning innenfor selskapsrett og forretningsjuridiske spørsmål.' },
    { id: 'arbeidsrett', icon: Users, title: 'Arbeidsrett', description: 'Bistand innenfor arbeidsforhold, oppsigelse og ansettelseskontrakter.' },
    { id: 'kontraktsrett', icon: Award, title: 'Kontraktsrett', description: 'Utforming og gjennomgang av avtaler og kontrakter.' },
    { id: 'familierett', icon: Shield, title: 'Familierett', description: 'Rådgivning innenfor familie- og arvesaker.' }
  ];

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % carouselImages.length);
  };

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + carouselImages.length) % carouselImages.length);
  };

  return (
    <div>
      {/* Hero Section */}
      <section className="relative h-96 md:h-[600px] bg-gray-900">
        <div 
          className="absolute inset-0 bg-cover bg-center grayscale"
          style={{
            backgroundImage: 'url(/Nidelva%20svart%20og%20hvit.jpg)'
          }}
        />
        <div className="absolute inset-0 bg-black bg-opacity-60" />
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-full flex items-center">
          <div className="text-white max-w-2xl">
            <h1 className="text-4xl md:text-6xl font-bold mb-6">
              Profesjonell juridisk rådgivning
            </h1>
            <p className="text-xl md:text-2xl mb-8 text-gray-200">
              Juridisk rådgivning og bistand innenfor alle fagfelt
            </p>
            <a
              href="#kontakt"
              className="inline-flex items-center px-8 py-4 bg-teal-600 text-white font-semibold rounded-lg hover:bg-teal-700 transition-colors"
            >
              Få en konsultasjon
              <ArrowRight className="ml-2 h-5 w-5" />
            </a>
          </div>
        </div>
        
        {/* Contact Cards */}
        <div className="absolute bottom-8 right-8 hidden lg:flex space-x-4">
          <div className="bg-white rounded-lg p-4 shadow-lg">
            <div className="flex items-center space-x-3">
              <Phone className="h-5 w-5 text-teal-600" />
              <div>
                <p className="text-sm text-gray-600">Ring oss</p>
                <p className="font-semibold text-gray-900">73 52 55 55</p>
              </div>
            </div>
          </div>
          <div className="bg-white rounded-lg p-4 shadow-lg">
            <div className="flex items-center space-x-3">
              <Mail className="h-5 w-5 text-teal-600" />
              <div>
                <p className="text-sm text-gray-600">Send e-post</p>
                <p className="font-semibold text-gray-900">firmapost@advokatmalm.no</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Våre tjenester
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Vi tilbyr profesjonell juridisk rådgivning innenfor flere spesialiserte fagfelt
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {services.map((service) => (
              <div key={service.id} className="bg-white p-6 rounded-lg shadow-lg border border-gray-100 hover:shadow-xl transition-shadow">
                <div className="w-12 h-12 bg-teal-100 rounded-lg flex items-center justify-center mb-4">
                  <service.icon className="h-6 w-6 text-teal-600" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">{service.title}</h3>
                <p className="text-gray-600 mb-4">{service.description}</p>
                <a href="#virksomhetsomrader" className="text-teal-600 font-semibold hover:text-teal-700 transition-colors">
                  Les mer →
                </a>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Carousel Section */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Vårt arbeid
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Se noen av våre nylige prosjekter og case studies
            </p>
          </div>
          
          <div className="relative">
            <div className="relative h-96 rounded-lg overflow-hidden">
              <img
                src={carouselImages[currentSlide]}
                alt={`Profesjonell juridisk bistand - slide ${currentSlide + 1}`}
                className="w-full h-full object-cover grayscale"
              />
              <div className="absolute inset-0 bg-black bg-opacity-40 flex items-center justify-center">
                <div className="text-white text-center">
                  <h3 className="text-2xl font-bold mb-2">Profesjonell juridisk bistand</h3>
                  <p className="text-lg">Vi leverer resultatbasert og kundevennlig service</p>
                </div>
              </div>
            </div>
            
            <button
              onClick={prevSlide}
              aria-label="Forrige bilde"
              className="absolute left-4 top-1/2 transform -translate-y-1/2 bg-white bg-opacity-80 hover:bg-opacity-100 rounded-full p-2 shadow-lg transition-all"
            >
              <ChevronLeft className="h-6 w-6 text-gray-800" />
            </button>
            
            <button
              onClick={nextSlide}
              aria-label="Neste bilde"
              className="absolute right-4 top-1/2 transform -translate-y-1/2 bg-white bg-opacity-80 hover:bg-opacity-100 rounded-full p-2 shadow-lg transition-all"
            >
              <ChevronRight className="h-6 w-6 text-gray-800" />
            </button>
            
            <div className="flex justify-center mt-4 space-x-2">
              {carouselImages.map((_, index) => (
                <button
                  key={index}
                  onClick={() => setCurrentSlide(index)}
                  aria-label={`Gå til slide ${index + 1}`}
                  className={`w-3 h-3 rounded-full transition-colors ${
                    currentSlide === index ? 'bg-teal-600' : 'bg-gray-300'
                  }`}
                />
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Info Card on Background */}
      <section className="py-16 bg-gray-900 text-white relative">
        <div 
          className="absolute inset-0 bg-cover bg-center opacity-20 grayscale"
          style={{
            backgroundImage: 'url(https://images.pexels.com/photos/7887817/pexels-photo-7887817.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2)'
          }}
        />
        <div className="relative max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            Over 25 år med erfaring
          </h2>
          <p className="text-xl text-gray-200 mb-8">
            Med mangeårig erfaring og dedikert innsats har vi hjulpet hundrevis av klienter med deres juridiske utfordringer.
          </p>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <div className="text-4xl font-bold text-amber-400 mb-2">500+</div>
              <p className="text-gray-300">Tilfredse klienter</p>
            </div>
            <div>
              <div className="text-4xl font-bold text-amber-400 mb-2">25+</div>
              <p className="text-gray-300">År med erfaring</p>
            </div>
            <div>
              <div className="text-4xl font-bold text-amber-400 mb-2">95%</div>
              <p className="text-gray-300">Suksessrate</p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
            Trenger du juridisk rådgivning?
          </h2>
          <p className="text-xl text-gray-600 mb-8">
            Vi er her for å hjelpe deg med dine juridiske spørsmål. Ta kontakt i dag for en gratis konsultasjon.
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <a
              href="#kontakt"
              className="inline-flex items-center justify-center px-8 py-4 bg-teal-600 text-white font-semibold rounded-lg hover:bg-teal-700 transition-colors"
            >
              Kontakt oss
              <ArrowRight className="ml-2 h-5 w-5" />
            </a>
            <a
              href="#priser"
              className="inline-flex items-center justify-center px-8 py-4 border-2 border-teal-600 text-teal-600 font-semibold rounded-lg hover:bg-teal-600 hover:text-white transition-colors"
            >
              Se våre priser
            </a>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;