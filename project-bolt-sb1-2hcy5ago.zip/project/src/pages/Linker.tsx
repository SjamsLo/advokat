import React from 'react';

const Linker: React.FC = () => {
  return (
    <div className="py-8 bg-white">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <h1 className="text-2xl font-bold text-gray-900 mb-6">
          Linker
        </h1>
        
        <div className="space-y-4 text-gray-700">
          <p>
            <a 
              href="https://domstol.no" 
              target="_blank" 
              rel="noopener noreferrer"
              className="text-teal-600 hover:text-teal-700 font-medium"
            >
              Domstol.no
            </a> er domstolenes eget nettsted hvor du får informasjon om begreper og hvordan en rettssak gjennomføres og de ulike aktørenes oppgaver.
          </p>
          
          <p>
            På <a 
              href="https://lovdata.no" 
              target="_blank" 
              rel="noopener noreferrer"
              className="text-teal-600 hover:text-teal-700 font-medium"
            >
              lovdata
            </a> har du tilgang til samtlige gjeldende lover og forskrifter, samt nyere avgjørelser i Høyesterett og lagmannsrettene.
          </p>
          
          <p>
            <a 
              href="https://advokatenhjelperdeg.no" 
              target="_blank" 
              rel="noopener noreferrer"
              className="text-teal-600 hover:text-teal-700 font-medium"
            >
              Advokatenhjelperdeg.no
            </a> er en tjeneste fra <a 
              href="https://advokatforeningen.no" 
              target="_blank" 
              rel="noopener noreferrer"
              className="text-teal-600 hover:text-teal-700 font-medium"
            >
              Advokatforeningen
            </a>. Hovedmålet med nettportalen er å gjøre advokatenes tjenester lettere tilgjengelige for forbrukere. Advokatforeningen ønsker samtidig å bidra til økt oppmerksomhet rundt juridiske spørsmål og juridisk risiko. Det er og et mål å formidle praktiske råd og tips slik at forbrukerne kan bli mer bevisste og effektive kjøpere av advokattjenester.
          </p>
          
          <p>
            På <a 
              href="https://jus.no" 
              target="_blank" 
              rel="noopener noreferrer"
              className="text-teal-600 hover:text-teal-700 font-medium"
            >
              jus.no
            </a> kan du få bistand i alt fra å finne en advokat til informasjon om vanlige juridiske problemer.
          </p>
        </div>
      </div>
    </div>
  );
};

export default Linker;