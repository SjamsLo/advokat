import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Scale, Users, Home, Heart, FileText, Calculator, Shield, Car } from 'lucide-react';

const Virksomhetsomrader: React.FC = () => {
  const practiceAreas = [
    {
      icon: Scale,
      title: 'Selskapsjus',
      description: 'Rådigving innenfor selskapsrett, opprettelse av selskaper og forretningsjuridiske spørsmål.',
    },
    {
      icon: Users,
      title: 'Arbeidsrett',
      description: 'Bistand innenfor arbeidsforhold, ansettelseskontrakter, oppsigelse og arbeidsvilkår.',
    },
    {
      icon: Home,
      title: 'Eiendomsrett',
      description: 'Juridisk rågivning innenfor eiendomssalg, kjøp og andre eiendomsforhold.',
    },
    {
      icon: Heart,
      title: 'Familierett',
      description: 'Rågivning innenfor arv, testamenter, samlivssaker og familieforhold.',
    },
    {
      icon: FileText,
      title: 'Kontraktsrett',
      description: 'Utforming, gjennomgang og fortolkning av avtaler og kontrakter.',
    },
    {
      icon: Calculator,
      title: 'Skatterett',
      description: 'Rågivning innenfor skatteforhold for privatpersoner og bedrifter.',
    },
    {
      icon: Shield,
      title: 'Straffesaker',
      description: 'Forsvar og bistand i straffesaker og rettslige forhold.',
    },
    {
      icon: Car,
      title: 'Forsikring',
      description: 'Rågivning innenfor forsikringsforhold og forsikringsspørsmål.',
    },
  ];

  return (
    <div>
      {/* Page Hero */}
      <section className="bg-gray-900 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">
              Virksomhetsområder
            </h1>
            <p className="text-xl text-gray-200">
              Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris.
            </p>
          </div>
        </div>
      </section>

      {/* Practice Areas Grid */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Våre spesialområder
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {practiceAreas.map((area, index) => (
              <div key={index} className="bg-white p-6 rounded-lg shadow-lg border border-gray-100 hover:shadow-xl transition-shadow">
                <div className="w-12 h-12 bg-teal-100 rounded-lg flex items-center justify-center mb-4">
                  <area.icon className="h-6 w-6 text-teal-600" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-3">{area.title}</h3>
                <p className="text-gray-600 mb-4">{area.description}</p>
                <Link
                  to="/kontakt"
                  className="inline-flex items-center text-teal-600 font-semibold hover:text-teal-700 transition-colors"
                >
                  Kontakt oss
                  <ArrowRight className="ml-1 h-4 w-4" />
                </Link>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Info Section */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-bold text-gray-900 mb-6">
                Bred juridisk kompetanse
              </h2>
              <p className="text-lg text-gray-600 mb-6">
                Våre advokater har bred kompetanse innenfor mange fagfelt. Vi kombinerer juridisk ekspertise med praktisk erfaring for å gi deg den beste mulige rågivningen.
              </p>
              <p className="text-lg text-gray-600 mb-8">
                Vi legger vekt på åpenhet, kommunikasjon og tilgjengelighet. Din sak er viktig for oss, og vi jobber dedikert for å oppnå best mulig resultat.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Link
                  to="/advokater"
                  className="inline-flex items-center px-6 py-3 bg-teal-600 text-white font-semibold rounded-lg hover:bg-teal-700 transition-colors"
                >
                  Møt våre advokater
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
                <Link
                  to="/kontakt"
                  className="inline-flex items-center px-6 py-3 border-2 border-teal-600 text-teal-600 font-semibold rounded-lg hover:bg-teal-600 hover:text-white transition-colors"
                >
                  Kontakt oss
                </Link>
              </div>
            </div>
            <div className="relative">
              <img
                src="https://images.pexels.com/photos/5668858/pexels-photo-5668858.jpeg?auto=compress&cs=tinysrgb&w=600&h=800&dpr=2"
                alt="Legal consultation"
                className="w-full h-96 object-cover rounded-lg shadow-lg filter grayscale"
              />
              <div className="absolute inset-0 bg-teal-600 bg-opacity-20 rounded-lg"></div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
            Har du spørsmål om våre tjenester?
          </h2>
          <p className="text-xl text-gray-600 mb-8">
            Kontakt oss i dag for å diskutere din juridiske behov. Vi gir deg en gratis initial konsultasjon.
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Link
              to="/kontakt"
              className="inline-flex items-center px-8 py-4 bg-teal-600 text-white font-semibold rounded-lg hover:bg-teal-700 transition-colors"
            >
              Kontakt oss i dag
              <ArrowRight className="ml-2 h-5 w-5" />
            </Link>
            <Link
              to="/priser"
              className="inline-flex items-center px-8 py-4 border-2 border-teal-600 text-teal-600 font-semibold rounded-lg hover:bg-teal-600 hover:text-white transition-colors"
            >
              Se våre priser
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Virksomhetsomrader;