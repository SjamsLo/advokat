import React from 'react';

const Personvern: React.FC = () => {
  return (
    <div className="py-8 bg-white">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <h1 className="text-4xl font-bold text-gray-900 mb-8">
          Personvern
        </h1>

        <div className="space-y-6 text-gray-700">
          <p className="text-lg leading-relaxed">
            Våre brukeres tillit er av største viktighet for oss og derfor følger vi en strikt integritetspolicy. Den forklarer hvordan og hvorfor vi samler inn og anvender informasjonskapsler (cookies), og hvordan vi beskytter brukernes integritet.
          </p>

          <div className="mt-12">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">
              Bruk av informasjonskapsler og andre måleverktøy
            </h2>

            <div className="space-y-6">
              <p className="leading-relaxed">
                Vi bruker informasjonskapsler for å gjøre det lettere å bruke våre websider og kan brukes for å personalisere visse deler av innholdet. En informasjonskapsel er en liten tekstfil som sendes fra vår webserver og lagres av din nettleser. Informasjonen som lagres kan være opplysninger om hvordan våre brukere har surfet på og anvendt våre nettsider, og om hvilken nettleser de har brukt.
              </p>

              <p className="leading-relaxed">
                Vi anvender statistikk om brukere og trafikk/trafikkleverandører i aggregert form. Statistikken inneholder aldri noen form for personlig informasjon, alt er anonymt. IP-adresser lagres ikke i vår database der vi lagrer atferd på nettstedet, derfor kan informasjon om deg som bruker aldri kobles sammen med din identitet. Din IP-adresse lagres av sikkerhetsmessige årsaker bare i de tilfeller du selv aktivt registrerer deg på nettstedet.
              </p>

              <div className="bg-gray-50 p-6 rounded-lg">
                <h3 className="text-lg font-bold text-gray-900 mb-4">
                  Formål:
                </h3>
                <ul className="space-y-3 list-disc list-inside">
                  <li>Utvikle og forbedre nettstedet gjennom å forstå hvordan det anvendes.</li>
                  <li>Beregne og rapportere brukerantall og trafikk.</li>
                  <li>Gjøre det lettere for deg å navigere på nettstedet.</li>
                  <li>Gjøre det mulig for systemet å kjenne igjen faste brukere for å kunne tilpasse tjenestene.</li>
                  <li>Iblant anvender vi tredjepartsinformasjonskapsler fra andre firma for å gjøre markedsundersøkelser og trafikkmålinger, og for å forbedre funksjonaliteten på nettstedet.</li>
                </ul>
              </div>
            </div>
          </div>

          <div className="mt-12">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">
              Slik forhindrer du at informasjonskapsler lagres
            </h2>

            <div className="space-y-6">
              <p className="leading-relaxed">
                Du kan slette informasjonskapsler fra din harddisk når som helst, men dette gjør at dine personlige innstillinger forsvinner. Du kan også endre innstillingene i din nettleser slik at den ikke tillater at informasjonskapsler lagres på din harddisk. Dette gir imidlertid dårligere funksjonalitet på visse websider, kan forhindre tilgang til medlemssider og gjøre at deler av innhold og enkelte funksjoner ikke blir tilgjengelige.
              </p>

              <p className="leading-relaxed">
                Hvis du ikke ønsker å bli sporet av Google Analytics kan dette deaktiveres på adressen:{' '}
                <a
                  href="http://tools.google.com/dlpage/gaoptout"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-teal-600 hover:text-teal-700 font-medium"
                >
                  http://tools.google.com/dlpage/gaoptout
                </a>
              </p>

              <p className="leading-relaxed">
                Mer informasjon om hvordan du kan unngå informasjonskapsler kan du lese på{' '}
                <a
                  href="https://www.allaboutcookies.org"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-teal-600 hover:text-teal-700 font-medium"
                >
                  www.allaboutcookies.org
                </a>.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Personvern;
