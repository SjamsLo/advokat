import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Mail, Phone, Linkedin } from 'lucide-react';

const Advokater: React.FC = () => {
  const lawyers = [
    {
      name: 'Ola Nordmann',
      title: 'Partner / Advokat',
      specialties: ['Selskapsjus', 'Kontraktsrett', 'M&A'],
      experience: '15 år erfaring',
      education: '',
      image: 'https://images.pexels.com/photos/2182970/pexels-photo-2182970.jpeg?auto=compress&cs=tinysrgb&w=300&h=400&dpr=2',
      email: 'lars.nordahl@nordisk.no',
      phone: '+47 123456789'
    }
  ];

  return (
    <div>
      {/* Page Hero */}
      <section className="bg-gray-900 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Breadcrumb */}
          <nav className="mb-8">
            <ol className="flex items-center space-x-2 text-sm">
              <li><Link to="/" className="text-gray-300 hover:text-white transition-colors">Hjem</Link></li>
              <li><span className="text-gray-400">/</span></li>
              <li><span className="text-white">Advokater</span></li>
            </ol>
          </nav>
          
          <div className="max-w-3xl">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">
              Våre advokater
            </h1>
            <p className="text-xl text-gray-200">
              Møt våre erfarne advokater som er dedikert til å gi deg den beste juridiske rågivningen.
            </p>
          </div>
        </div>
      </section>

      {/* Lawyers Grid */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {lawyers.map((lawyer, index) => (
              <div key={index} className="bg-white rounded-lg shadow-lg overflow-hidden border border-gray-100 hover:shadow-xl transition-shadow">
                <div className="aspect-[3/4] overflow-hidden">
                  <img
                    src={lawyer.image}
                    alt={lawyer.name}
                    className="w-full h-full object-cover filter grayscale hover:grayscale-0 transition-all duration-300"
                  />
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-bold text-gray-900 mb-1">{lawyer.name}</h3>
                  <p className="text-teal-600 font-semibold mb-2">{lawyer.title}</p>
                  <p className="text-sm text-gray-600 mb-4">{lawyer.experience}</p>
                  
                  <div className="mb-4">
                    <h4 className="text-sm font-semibold text-gray-900 mb-2">Spesialområder:</h4>
                    <div className="flex flex-wrap gap-1">
                      {lawyer.specialties.map((specialty, idx) => (
                        <span key={idx} className="px-2 py-1 bg-teal-100 text-teal-800 text-xs rounded-full">
                          {specialty}
                        </span>
                      ))}
                    </div>
                  </div>
                  
                  <div className="mb-4">
                    <h4 className="text-sm font-semibold text-gray-900 mb-1">Utdanning:</h4>
                    <p className="text-sm text-gray-600">{lawyer.education}</p>
                  </div>
                  
                  <div className="flex items-center space-x-4 pt-4 border-t border-gray-200">
                    <a
                      href={`mailto:${lawyer.email}`}
                      className="flex items-center space-x-1 text-teal-600 hover:text-teal-700 transition-colors"
                    >
                      <Mail className="h-4 w-4" />
                      <span className="text-sm">E-post</span>
                    </a>
                    <a
                      href={`tel:${lawyer.phone}`}
                      className="flex items-center space-x-1 text-teal-600 hover:text-teal-700 transition-colors"
                    >
                      <Phone className="h-4 w-4" />
                      <span className="text-sm">Ring</span>
                    </a>
                    <a
                      href="#"
                      className="flex items-center space-x-1 text-teal-600 hover:text-teal-700 transition-colors"
                    >
                      <Linkedin className="h-4 w-4" />
                      <span className="text-sm">LinkedIn</span>
                    </a>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
            Få juridisk rådgivning fra våre eksperter
          </h2>
          <p className="text-xl text-gray-600 mb-8">
            Våre eksperter har bred erfaring og er klare til å hjelpe deg med dine juridiske behov.
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Link
              to="/kontakt"
              className="inline-flex items-center px-8 py-4 bg-teal-600 text-white font-semibold rounded-lg hover:bg-teal-700 transition-colors"
            >
              Bestill konsultasjon
              <ArrowRight className="ml-2 h-5 w-5" />
            </Link>
            <Link
              to="/priser"
              className="inline-flex items-center px-8 py-4 border-2 border-teal-600 text-teal-600 font-semibold rounded-lg hover:bg-teal-600 hover:text-white transition-colors"
            >
              Se våre priser
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Advokater;