import React, { useState, useRef, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, ChevronDown } from 'lucide-react';

const Header: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const location = useLocation();
  const dropdownRef = useRef<HTMLDivElement>(null);

  const navigationItems = [
    { name: 'Hjem', path: '/' },
    { name: 'Advokater', path: '/advokater' },
    { name: 'Virksomhetsområder', path: '/virksomhetsomrader', hasDropdown: true },
    { name: 'Priser', path: '/priser' },
    { name: 'Artikler', path: '/artikler' },
    { name: 'Linker', path: '/linker' },
    { name: 'Kontakt', path: '/kontakt' },
  ];

  const practiceAreas = [
    { name: 'Selskapsjus', path: '/virksomhetsomrader' },
    { name: 'Arbeidsrett', path: '/virksomhetsomrader' },
    { name: 'Eiendomsrett', path: '/virksomhetsomrader' },
    { name: 'Familierett', path: '/virksomhetsomrader' },
    { name: 'Kontraktsrett', path: '/virksomhetsomrader' },
    { name: 'Skatterett', path: '/virksomhetsomrader' },
    { name: 'Straffesaker', path: '/virksomhetsomrader' },
    { name: 'Forsikring', path: '/virksomhetsomrader' },
  ];

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsDropdownOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleDropdownToggle = () => {
    setIsDropdownOpen(!isDropdownOpen);
  };

  return (
    <>
      <header className="bg-white shadow-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            {/* Logo */}
            <Link to="/" className="flex items-center space-x-2">
              <span className="text-xl font-bold text-gray-900">Advokat Håkon Malm</span>
            </Link>

            {/* Desktop Navigation */}
            <nav className="hidden lg:flex items-center space-x-8">
              {navigationItems.map((item) => (
                <div key={item.name} className="relative" ref={item.hasDropdown ? dropdownRef : undefined}>
                  {item.hasDropdown ? (
                    <button
                      onClick={handleDropdownToggle}
                      className={`flex items-center space-x-1 px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                        location.pathname === item.path
                          ? 'text-teal-600 bg-teal-50'
                          : 'text-gray-700 hover:text-teal-600 hover:bg-gray-50'
                      }`}
                    >
                      <span>{item.name}</span>
                      <ChevronDown className={`h-4 w-4 transition-transform ${isDropdownOpen ? 'rotate-180' : ''}`} />
                    </button>
                  ) : (
                    <Link
                      to={item.path}
                      className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                        location.pathname === item.path
                          ? 'text-teal-600 bg-teal-50'
                          : 'text-gray-700 hover:text-teal-600 hover:bg-gray-50'
                      }`}
                    >
                      {item.name}
                    </Link>
                  )}
                </div>
              ))}
            </nav>

            {/* Mobile menu button */}
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="lg:hidden p-2 rounded-md text-gray-700 hover:text-teal-600 hover:bg-gray-50"
            >
              {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="lg:hidden bg-white border-t">
            <div className="px-4 pt-2 pb-3 space-y-1">
              {navigationItems.map((item) => (
                <Link
                  key={item.name}
                  to={item.path}
                  className={`block px-3 py-2 rounded-md text-base font-medium ${
                    location.pathname === item.path
                      ? 'text-teal-600 bg-teal-50'
                      : 'text-gray-700 hover:text-teal-600 hover:bg-gray-50'
                  }`}
                  onClick={() => setIsMenuOpen(false)}
                >
                  {item.name}
                </Link>
              ))}
            </div>
          </div>
        )}
      </header>

      {/* Dropdown Menu */}
      {isDropdownOpen && (
        <div className="fixed inset-0 z-40">
          <div className="absolute inset-0 bg-black bg-opacity-25" onClick={() => setIsDropdownOpen(false)} />
          <div className="relative bg-white shadow-lg" style={{ height: 'auto' }}>
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
              <div className="flex justify-between items-start mb-8">
                <h2 className="text-2xl font-bold text-gray-900">Virksomhetsområder</h2>
                <button
                  onClick={() => setIsDropdownOpen(false)}
                  className="p-2 rounded-md text-gray-400 hover:text-gray-600 hover:bg-gray-100"
                >
                  <X className="h-6 w-6" />
                </button>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                {practiceAreas.map((area, index) => (
                  <Link
                    key={index}
                    to={area.path}
                    className="group p-4 hover:bg-gray-50 transition-colors cursor-pointer"
                    onClick={() => setIsDropdownOpen(false)}
                  >
                    <h3 className="text-lg font-semibold text-gray-900 group-hover:text-teal-600 transition-colors">
                      {area.name}
                    </h3>
                    <p className="mt-2 text-sm text-gray-600">
                      Kontakt for mer informasjon.
                    </p>
                  </Link>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default Header;