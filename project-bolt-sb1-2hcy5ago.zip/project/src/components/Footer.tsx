import React from 'react';
import { Link } from 'react-router-dom';
import { Phone, Mail, MapPin, Scale } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-gray-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Company Info */}
          <div>
            <div className="flex items-center space-x-2 mb-4">
              <Scale className="h-8 w-8 text-teal-400" />
              <span className="text-xl font-bold">Advokat Håkon Malm</span>
            </div>
            <p className="text-gray-300 mb-4">
              Advokatfirmaet Håkon Malm har kontor i 3. etasje i Nordre gate 1 "Gamle adressa-huset" i Trondheim.
            </p>
          </div>

          {/* Contact Info */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Kontaktinformasjon</h3>
            <div className="space-y-3">
              <div className="flex items-center space-x-3">
                <MapPin className="h-5 w-5 text-teal-400" />
                <div>
                  <p className="text-gray-300">Nordre gate 1</p>
                  <p className="text-gray-300">Postboks 1787, Sentrum</p>
                  <p className="text-gray-300">7011 Trondheim</p>
                </div>
              </div>
              <div className="flex items-center space-x-3">
                <Phone className="h-5 w-5 text-teal-400" />
                <div>
                  <p className="text-gray-300">73 52 55 55</p>
                  <p className="text-gray-300">959 64 550</p>
                </div>
              </div>
              <div className="flex items-center space-x-3">
                <Mail className="h-5 w-5 text-teal-400" />
                <p className="text-gray-300">firmapost@advokatmalm.no</p>
              </div>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Snarveier</h3>
            <div className="space-y-2">
              <Link to="/advokater" className="block text-gray-300 hover:text-teal-400 transition-colors">
                Våre advokater
              </Link>
              <Link to="/virksomhetsomrader" className="block text-gray-300 hover:text-teal-400 transition-colors">
                Virksomhetsområder
              </Link>
              <Link to="/priser" className="block text-gray-300 hover:text-teal-400 transition-colors">
                Priser og vilkår
              </Link>
              <Link to="/kontakt" className="block text-gray-300 hover:text-teal-400 transition-colors">
                Kontakt oss
              </Link>
            </div>
          </div>
        </div>

        <div className="mt-8 pt-8 border-t border-gray-800">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-400 text-sm">
              © 2025 Advokatfirmaet Håkon Malm
            </p>
            <div className="mt-4 md:mt-0 flex space-x-6">
              <Link to="/personvern" className="text-gray-400 hover:text-teal-400 text-sm transition-colors">
                Personvern
              </Link>
              <a href="#" className="text-gray-400 hover:text-teal-400 text-sm transition-colors">
                Cookies
              </a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;